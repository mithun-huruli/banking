<?php
$servername="sql303.epizy.com";
$username="epiz_27232699";
$password="4QMVd8aRMKqW2n";
$db_name="epiz_27232699_banking";
// Create connection
$conn=mysqli_connect("$servername", "$username", "$password") or die("cannot connect");

mysqli_select_db($conn,"$db_name") or die("cannot select DB");

?>